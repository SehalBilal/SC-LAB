package view;

import javax.swing.*;
import java.awt.*;
import controller.GenerateReportController;

public class GenerateReportView extends JFrame {
    public GenerateReportView(GenerateReportController controller) {
        setTitle("Generate Report");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(500, 300);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        JLabel label = new JLabel("Generate Report - Placeholder", SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 22));
        add(label, BorderLayout.CENTER);
        JButton backBtn = new JButton("Back to Dashboard");
        backBtn.addActionListener(e -> controller.backToDashboard());
        add(backBtn, BorderLayout.SOUTH);
    }
} 