package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import java.util.*;
import controller.RegisterCoursesController;
import model.CourseModel;
import model.UserModel;

public class RegisterCoursesView extends JFrame {
    private JButton[] menuButtons;
    private String[] buttonLabels = {
        "Dashboard", "Register Courses", "Courses List", "Academic Report", "Time Table", "Logout"
    };
    private String[] iconFiles = {
        "/dashboard.png",
        "/registercourses.png",
        "/courseslist.png",
        "/academicreport.png",
        "/timetable.png",
        "/logout.png"
    };
    private JPanel contentPanel;
    private int activeIndex = 1;
    private DefaultTableModel tableModel;
    private JTextField courseCodeField;
    private JLabel creditLabel;
    private int totalCredits = 0;
    private Set<String> addedCourses = new HashSet<>();
    private RegisterCoursesController controller;
    private CourseModel courseModel;
    private UserModel userModel;
    private String username;
    private JTable courseTable;
    private JButton confirmButton;

    public RegisterCoursesView(RegisterCoursesController controller, CourseModel courseModel, UserModel userModel, String username) {
        this.controller = controller;
        this.courseModel = courseModel;
        this.userModel = userModel;
        this.username = username;
        
        setTitle("QAU Student Console");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1100, 700));
        setLocationRelativeTo(null);

        // Custom background panel with image and green overlay
        JPanel background = new JPanel(new BorderLayout()) {
            Image bg = new ImageIcon("Student course registration system/background.jpg").getImage();
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(bg, 0, 0, getWidth(), getHeight(), this);
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setColor(new Color(34, 139, 34, 180));
                g2d.fillRect(0, 0, getWidth(), getHeight());
                g2d.dispose();
            }
        };
        setContentPane(background);

        // HEADER BAR
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(0, 160, 120));
        header.setPreferredSize(new Dimension(0, 80));

        // Left: Logo + Label
        JPanel leftPanel = new JPanel();
        leftPanel.setOpaque(false);
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.X_AXIS));
        JPanel logoPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Image img = new ImageIcon("Student course registration system/logo.png").getImage();
                int size = Math.min(getWidth(), getHeight());
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setClip(new java.awt.geom.Ellipse2D.Float(0, 0, size, size));
                g2.drawImage(img, 0, 0, size, size, this);
                g2.setClip(null);
                g2.setColor(Color.WHITE);
                g2.setStroke(new BasicStroke(3));
                g2.drawOval(0, 0, size-1, size-1);
                g2.dispose();
            }
        };
        logoPanel.setPreferredSize(new Dimension(64, 64));
        logoPanel.setOpaque(false);
        leftPanel.add(Box.createRigidArea(new Dimension(16, 0)));
        leftPanel.add(logoPanel);
        leftPanel.add(Box.createRigidArea(new Dimension(16, 0)));
        JLabel consoleLabel = new JLabel("QAU STUDENT CONSOLE");
        consoleLabel.setFont(new Font("Century Gothic", Font.BOLD, 24));
        consoleLabel.setForeground(Color.WHITE);
        leftPanel.add(consoleLabel);
        header.add(leftPanel, BorderLayout.WEST);

        // Center: Welcome
        JLabel welcome = new JLabel("Welcome : " + username, SwingConstants.CENTER);
        welcome.setFont(new Font("Century Gothic", Font.BOLD, 20));
        welcome.setForeground(Color.WHITE);
        header.add(welcome, BorderLayout.CENTER);

        background.add(header, BorderLayout.NORTH);

        // MENU BAR
        JPanel menuPanel = new JPanel();
        menuPanel.setOpaque(false);
        menuPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 24, 24));
        menuButtons = new JButton[buttonLabels.length];

        for (int i = 0; i < buttonLabels.length; i++) {
            JButton btn = new JButton(buttonLabels[i]);
            btn.setFont(new Font("Century Gothic", Font.BOLD, 14));
            btn.setVerticalTextPosition(SwingConstants.BOTTOM);
            btn.setHorizontalTextPosition(SwingConstants.CENTER);
            btn.setIcon(new ImageIcon(new ImageIcon("Student course registration system" + iconFiles[i]).getImage().getScaledInstance(48, 48, Image.SCALE_SMOOTH)));
            btn.setPreferredSize(new Dimension(110, 90));
            btn.setFocusPainted(false);
            btn.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
            btn.setBackground(Color.WHITE);
            btn.setOpaque(true);

            final int idx = i;
            btn.addActionListener(e -> {
                setActiveButton(idx);
                controller.navigateTo(idx);
            });

            menuButtons[i] = btn;
            menuPanel.add(btn);
        }
        setActiveButton(activeIndex);

        // Main content area (white panel)
        contentPanel = new JPanel();
        contentPanel.setBackground(Color.WHITE);
        contentPanel.setBorder(BorderFactory.createEmptyBorder(24, 24, 24, 24));
        contentPanel.setLayout(new BorderLayout());

        // Register Courses Panel
        JPanel registerPanel = new JPanel(new BorderLayout());
        registerPanel.setBackground(Color.WHITE);

        // Top section with course code input
        JPanel inputPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 20));
        inputPanel.setBackground(Color.WHITE);
        
        JLabel courseCodeLabel = new JLabel("Course Code:");
        courseCodeField = new JTextField(10);
        JButton addButton = new JButton("Add Course");
        addButton.setBackground(new Color(0, 160, 120));
        addButton.setForeground(Color.WHITE);
        addButton.setFocusPainted(false);
        addButton.addActionListener(e -> registerCourse());
        
        creditLabel = new JLabel("Total Credits: 0");
        creditLabel.setFont(new Font("Arial", Font.BOLD, 14));
        
        inputPanel.add(courseCodeLabel);
        inputPanel.add(courseCodeField);
        inputPanel.add(addButton);
        inputPanel.add(Box.createRigidArea(new Dimension(20, 0)));
        inputPanel.add(creditLabel);
        
        registerPanel.add(inputPanel, BorderLayout.NORTH);

        // Center section with table
        String[] columnNames = {"Course Code", "Course Name", "Credits", "Teacher", "Room"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        courseTable = new JTable(tableModel);
        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
        renderer.setHorizontalAlignment(SwingConstants.CENTER);
        for (int i = 0; i < columnNames.length; i++) {
            courseTable.getColumnModel().getColumn(i).setCellRenderer(renderer);
        }
        JScrollPane scrollPane = new JScrollPane(courseTable);
        registerPanel.add(scrollPane, BorderLayout.CENTER);

        // Confirm button
        confirmButton = new JButton("Confirm");
        confirmButton.setBackground(new Color(0, 160, 120));
        confirmButton.setForeground(Color.WHITE);
        confirmButton.setFont(new Font("Arial", Font.BOLD, 16));
        confirmButton.setFocusPainted(false);
        confirmButton.addActionListener(e -> confirmRegistration());
        JPanel confirmPanel = new JPanel();
        confirmPanel.setBackground(Color.WHITE);
        confirmPanel.add(confirmButton);
        registerPanel.add(confirmPanel, BorderLayout.SOUTH);

        contentPanel.add(registerPanel, BorderLayout.CENTER);

        // Center panel to hold menu and content
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setOpaque(false);
        centerPanel.add(menuPanel, BorderLayout.NORTH);
        centerPanel.add(contentPanel, BorderLayout.CENTER);

        background.add(centerPanel, BorderLayout.CENTER);
    }

    private void setActiveButton(int idx) {
        for (int i = 0; i < menuButtons.length; i++) {
            if (i == idx) {
                menuButtons[i].setBackground(new Color(0, 160, 120));
                menuButtons[i].setForeground(Color.WHITE);
            } else {
                menuButtons[i].setBackground(Color.WHITE);
                menuButtons[i].setForeground(Color.BLACK);
            }
        }
        activeIndex = idx;
    }

    private void registerCourse() {
        String courseCode = courseCodeField.getText().trim().toUpperCase();
        if (courseCode.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a course code!");
            return;
        }
        if (addedCourses.contains(courseCode)) {
            JOptionPane.showMessageDialog(this, "Course already added!");
            return;
        }
        Map<String, Object> courseDetails = courseModel.getCourseDetails(courseCode);
        if (courseDetails == null) {
            JOptionPane.showMessageDialog(this, "Invalid course code!");
            return;
        }
        int courseCredits = (Integer) courseDetails.get("credits");
        if (totalCredits + courseCredits > 18) {
            JOptionPane.showMessageDialog(this, "Cannot add course. Total credits would exceed 18!");
            return;
        }
        
        // Use controller to validate and register course
        if (controller.registerCourse(courseCode)) {
            // Only add to table if registration was successful
            tableModel.addRow(new Object[]{
                courseCode,
                courseDetails.get("name"),
                courseDetails.get("credits"),
                courseDetails.get("teacher"),
                courseDetails.get("room")
            });
            addedCourses.add(courseCode);
            totalCredits += courseCredits;
            creditLabel.setText("Total Credits: " + totalCredits);
            courseCodeField.setText("");
            JOptionPane.showMessageDialog(this, "Course registered successfully!");
        }
    }

    private void confirmRegistration() {
        if (addedCourses.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No courses to confirm!");
            return;
        }
        // Save all courses in the table to the user model
        userModel.clearRegisteredCourses(username);
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            Object code = tableModel.getValueAt(i, 0);
            if (code != null && !code.toString().isEmpty()) {
                String[] course = new String[5];
                for (int j = 0; j < 5; j++) {
                    course[j] = tableModel.getValueAt(i, j).toString();
                }
                userModel.addRegisteredCourse(username, course);
            }
        }
        JOptionPane.showMessageDialog(this, "Courses registered successfully!");
        // Optionally clear table and reset
        tableModel.setRowCount(0);
        addedCourses.clear();
        totalCredits = 0;
        creditLabel.setText("Total Credits: 0");
    }
} 