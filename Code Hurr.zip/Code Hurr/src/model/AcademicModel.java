package model;

import java.util.*;

public class AcademicModel {
    public static class Subject {
        String code, title;
        int creditHours;
        double marks;
        public Subject(String code, String title, int creditHours, double marks) {
            this.code = code;
            this.title = title;
            this.creditHours = creditHours;
            this.marks = marks;
        }
    }

    private List<String> semesters;
    private Map<String, List<Subject>> semesterSubjects;
    private Map<String, List<Map<String, Object>>> studentCourses;
    private Map<String, Map<String, Double>> studentStats;
    private static final String STUDENT_USERNAME = "04072313001";
    private static final Map<String, String> PRE_REQS = Map.of(
        "OOP", "PSP",
        "DSA", "OOP",
        "ADSS", "HCI",
        "COAL", "ICO",
        "PHY II", "PHY I",
        "MATH II", "MATH I",
        "ENG II", "ENG I"
    );
    private Map<String, Map<String, Map<String, Object>>> studentSemesterRecords;
    private Map<String, List<String>> studentSemesters;

    public AcademicModel() {
        semesters = Arrays.asList("Spring 2023", "Fall 2023", "Spring 2024", "Fall 2024");
        semesterSubjects = new HashMap<>();
        studentCourses = new HashMap<>();
        studentStats = new HashMap<>();
        studentSemesterRecords = new HashMap<>();
        studentSemesters = new HashMap<>();
        setupStudentRecords();
    }

    private void setupStudentRecords() {
        // For student 04072313001 (Muhammad ALI)
        Map<String, Map<String, Object>> s1 = new LinkedHashMap<>();
        // Spring 2023
        s1.put("PSP", Map.of("name", "PSP", "marks", 80, "credits", 3));
        s1.put("ICT", Map.of("name", "ICT", "marks", 80, "credits", 3));
        s1.put("PHY THEORY I", Map.of("name", "PHY THEORY I", "marks", 80, "credits", 2));
        s1.put("PHY LAB I", Map.of("name", "PHY LAB I", "marks", 58, "credits", 1));
        s1.put("ENG", Map.of("name", "ENG", "marks", 80, "credits", 3));
        s1.put("PAK STUDIES", Map.of("name", "PAK STUDIES", "marks", 80, "credits", 2));
        s1.put("MATH I", Map.of("name", "MATH I", "marks", 80, "credits", 3));
        // Fall 2023
        Map<String, Map<String, Object>> s2 = new LinkedHashMap<>();
        s2.put("OOP", Map.of("name", "OOP", "marks", 90, "credits", 4));
        s2.put("MATH II", Map.of("name", "MATH II", "marks", 85, "credits", 3));
        s2.put("ISL", Map.of("name", "ISL", "marks", 80, "credits", 2));
        s2.put("PHY TH II", Map.of("name", "PHY TH II", "marks", 82, "credits", 2));
        s2.put("PHY LAB II", Map.of("name", "PHY LAB II", "marks", 68, "credits", 1));
        s2.put("ENG II", Map.of("name", "ENG II", "marks", 89, "credits", 3));
        s2.put("DM", Map.of("name", "DM", "marks", 81, "credits", 3));
        // Spring 2024
        Map<String, Map<String, Object>> s3 = new LinkedHashMap<>();
        s3.put("DSA THEORY", Map.of("name", "DSA THEORY", "marks", 77, "credits", 3));
        s3.put("DSA LAB", Map.of("name", "DSA LAB", "marks", 80, "credits", 1));
        s3.put("ENG III", Map.of("name", "ENG III", "marks", 73, "credits", 3));
        s3.put("HCI", Map.of("name", "HCI", "marks", 45, "credits", 3));
        s3.put("ICO", Map.of("name", "ICO", "marks", 72, "credits", 3));
        s3.put("PSY", Map.of("name", "PSY", "marks", 76, "credits", 3));
        // Fall 2024 (empty, to be registered)
        Map<String, Map<String, Object>> s4 = new LinkedHashMap<>();
        studentSemesterRecords = new HashMap<>();
        studentSemesterRecords.put("Spring 2023", s1);
        studentSemesterRecords.put("Fall 2023", s2);
        studentSemesterRecords.put("Spring 2024", s3);
        studentSemesterRecords.put("Fall 2024", s4);
        studentSemesters.put(STUDENT_USERNAME, Arrays.asList("Spring 2023", "Fall 2023", "Spring 2024", "Fall 2024"));
    }

    private void setupDummyData() {
        semesterSubjects.put("Spring 2023", Arrays.asList(
            new Subject("CS-105 PSP", "Problem Solving & Programming", 3, 45),
            new Subject("CS-101 ICT", "Introduction to Computing", 3, 80),
            new Subject("EN-101", "English - 1", 3, 80),
            new Subject("PS-101", "Pakistan Studies", 3, 80),
            new Subject("MA-101", "Calculus & Analytical Geometry", 3, 75)
        ));
        semesterSubjects.put("Fall 2022", Arrays.asList(
            new Subject("CS-102", "Data Structures", 3, 85),
            new Subject("MA-102", "Linear Algebra", 3, 70),
            new Subject("EN-102", "English - 2", 3, 65)
        ));
    }

    private void initializeSampleData() {
        // Sample data for a student
        String username = "student1";
        List<Map<String, Object>> courses = new ArrayList<>();
        
        // Add some sample courses with grades
        addCourseToStudent(username, "CS101", "Introduction to Programming", 3, "A", 4.0);
        addCourseToStudent(username, "CS102", "Data Structures", 3, "B+", 3.3);
        addCourseToStudent(username, "CS201", "Database Systems", 3, "A-", 3.7);
        
        // Calculate and store stats
        calculateStats(username);
    }

    private void addCourseToStudent(String username, String code, String name, int credits, String grade, double gradePoints) {
        Map<String, Object> course = new HashMap<>();
        course.put("code", code);
        course.put("name", name);
        course.put("credits", credits);
        course.put("grade", grade);
        course.put("gradePoints", gradePoints);
        
        studentCourses.computeIfAbsent(username, k -> new ArrayList<>()).add(course);
    }

    private void calculateStats(String username) {
        List<Map<String, Object>> courses = studentCourses.get(username);
        if (courses == null) return;

        double totalPoints = 0;
        int totalCredits = 0;
        
        for (Map<String, Object> course : courses) {
            double gradePoints = (Double) course.get("gradePoints");
            int credits = (Integer) course.get("credits");
            totalPoints += gradePoints * credits;
            totalCredits += credits;
        }

        double gpa = totalCredits > 0 ? totalPoints / totalCredits : 0.0;
        
        Map<String, Double> stats = new HashMap<>();
        stats.put("gpa", gpa);
        stats.put("cgpa", gpa); // In a real system, CGPA would be calculated differently
        studentStats.put(username, stats);
    }

    public List<String> getSemesters() {
        // Exclude the current semester (Fall 2024) from the academic report
        List<String> filtered = new ArrayList<>();
        for (String sem : semesters) {
            if (!sem.equals("Fall 2024")) {
                filtered.add(sem);
            }
        }
        return filtered;
    }

    public List<Subject> getSubjectsForSemester(String semester) {
        return semesterSubjects.get(semester);
    }

    public static double calculateSubjectGPA(double marksObtained) {
        if (marksObtained >= 80) return 4.0;
        else if (marksObtained >= 76) return 3.8;
        else if (marksObtained >= 72) return 3.5;
        else if (marksObtained >= 68) return 3.0;
        else if (marksObtained >= 64) return 2.8;
        else if (marksObtained >= 60) return 2.5;
        else if (marksObtained >= 55) return 2.0;
        else if (marksObtained >= 50) return 1.0;
        else return 0.0;
    }

    public static String getGrade(double mark) {
        if (mark >= 80) return "A";
        else if (mark >= 76) return "A-";
        else if (mark >= 72) return "B+";
        else if (mark >= 68) return "B";
        else if (mark >= 64) return "B-";
        else if (mark >= 60) return "C+";
        else if (mark >= 55) return "C";
        else if (mark >= 50) return "D";
        else return "F";
    }

    public double calculateSemesterGPA(String semester) {
        List<Subject> subjects = semesterSubjects.get(semester);
        if (subjects == null) return 0.0;
        
        int totalCreditHours = 0;
        double semesterGPA = 0.0;
        for (Subject subject : subjects) {
            totalCreditHours += subject.creditHours;
            semesterGPA += calculateSubjectGPA(subject.marks) * subject.creditHours;
        }
        return Math.round((semesterGPA / totalCreditHours) * 100.0) / 100.0;
    }

    public double calculateCGPA() {
        double totalGPA = 0.0;
        int count = 0;
        for (String sem : semesters) {
            totalGPA += calculateSemesterGPA(sem);
            count++;
        }
        return Math.round((totalGPA / count) * 100.0) / 100.0;
    }

    public List<Map<String, Object>> getStudentCourses(String username) {
        return studentCourses.getOrDefault(username, new ArrayList<>());
    }

    public Map<String, Double> getStudentStats(String username) {
        return studentStats.getOrDefault(username, new HashMap<>());
    }

    public Map<String, Map<String, Object>> getSemesterRecords(String username, String semester) {
        return studentSemesterRecords.getOrDefault(semester, new LinkedHashMap<>());
    }

    public boolean isPreReqPassed(String username, String courseCode) {
        // First check if course is already passed
        if (isCoursePassed(username, courseCode)) {
            return false; // Can't register a course that's already passed
        }
        
        // If no pre-req, return true
        if (!PRE_REQS.containsKey(courseCode)) return true;
        
        String preReq = PRE_REQS.get(courseCode);
        // Find the semester where pre-req was taken
        for (String sem : studentSemesters.get(username)) {
            Map<String, Map<String, Object>> recs = studentSemesterRecords.get(sem);
            if (recs != null && recs.containsKey(preReq)) {
                int marks = (int) recs.get(preReq).get("marks");
                // Check if marks are passing (>= 50)
                return marks >= 50;
            }
        }
        return false; // Pre-req not found or not passed
    }

    public boolean isCoursePassed(String username, String courseCode) {
        // Check all semesters except the current one (Fall 2024)
        for (String sem : studentSemesters.get(username)) {
            if (sem.equals("Fall 2024")) continue; // Skip current semester
            Map<String, Map<String, Object>> recs = studentSemesterRecords.get(sem);
            if (recs != null && recs.containsKey(courseCode)) {
                int marks = (int) recs.get(courseCode).get("marks");
                return marks >= 50; // Course is passed if marks >= 50
            }
        }
        return false;
    }

    // List of available courses for Fall 2024
    private static final List<String> FALL_2024_COURSES = Arrays.asList(
        "COAL", "COAL LAB", "DBS", "CHEM TH", "CHEM LAB", "MATH III", "HCI"
    );

    public boolean isCourseAvailableForRegistration(String courseCode) {
        return FALL_2024_COURSES.contains(courseCode);
    }

    public double calculateSemesterCGPA(String username, String semester) {
        Map<String, Map<String, Object>> recs = getSemesterRecords(username, semester);
        double totalPoints = 0;
        int totalCredits = 0;
        for (Map<String, Object> subj : recs.values()) {
            int marks = (int) subj.get("marks");
            int credits = (int) subj.get("credits");
            double gp = calculateSubjectGPA(marks);
            totalPoints += gp * credits;
            totalCredits += credits;
        }
        return totalCredits > 0 ? Math.round((totalPoints / totalCredits) * 100.0) / 100.0 : 0.0;
    }

    public double calculateOverallCGPA(String username) {
        double totalPoints = 0;
        int totalCredits = 0;
        for (String sem : studentSemesters.get(username)) {
            Map<String, Map<String, Object>> recs = getSemesterRecords(username, sem);
            for (Map<String, Object> subj : recs.values()) {
                int marks = (int) subj.get("marks");
                int credits = (int) subj.get("credits");
                double gp = calculateSubjectGPA(marks);
                totalPoints += gp * credits;
                totalCredits += credits;
            }
        }
        return totalCredits > 0 ? Math.round((totalPoints / totalCredits) * 100.0) / 100.0 : 0.0;
    }
} 