package model;

import java.util.*;

public class CourseModel {
    private Map<String, Map<String, Object>> courses;

    public CourseModel() {
        courses = new HashMap<>();
        // 1st Semester
        addCourse("PSP", "Problem Solving & Programming", 3, "Dr. Naqi", "217");
        addCourse("ICT", "Introduction to Computing", 3, "Dr. Ali", "201");
        addCourse("PHY THEORY I", "Physics Theory I", 2, "Dr. Ahmed", "301");
        addCourse("PHY LAB I", "Physics Lab I", 1, "Dr. Ahmed", "Lab 1");
        addCourse("ENG", "English I", 3, "Ms. Sara", "105");
        addCourse("PAK STUDIES", "Pakistan Studies", 2, "Mr. Khan", "109");
        addCourse("MATH I", "Mathematics I", 3, "Dr. Ahmed", "301");
        // 2nd Semester
        addCourse("OOP", "Object Oriented Programming", 4, "Dr. Java", "202");
        addCourse("MATH II", "Mathematics II", 3, "Dr. Ahmed", "302");
        addCourse("ISL", "Islamic Studies", 2, "Mr. Usman", "110");
        addCourse("PHY TH II", "Physics Theory II", 2, "Dr. Ahmed", "303");
        addCourse("PHY LAB II", "Physics Lab II", 1, "Dr. Ahmed", "Lab 2");
        addCourse("ENG II", "English II", 3, "Ms. Sara", "106");
        addCourse("DM", "Discrete Mathematics", 3, "Dr. Discrete", "304");
        // 3rd Semester
        addCourse("DSA THEORY", "Data Structures & Algorithms Theory", 3, "Dr. Algo", "305");
        addCourse("DSA LAB", "Data Structures & Algorithms Lab", 1, "Dr. Algo", "Lab 3");
        addCourse("ENG III", "English III", 3, "Ms. Sara", "107");
        addCourse("HCI", "Human Computer Interaction", 3, "Dr. UI", "306");
        addCourse("ICO", "Introduction to Computer Organization", 3, "Dr. Org", "307");
        addCourse("PSY", "Psychology", 3, "Dr. Mind", "308");
        // 4th Semester
        addCourse("COAL", "Computer Organization and Assembly Language", 3, "Dr. Assembly", "309");
        addCourse("COAL LAB", "COAL Lab", 1, "Dr. Assembly", "Lab 4");
        addCourse("MATH III", "Mathematics III", 3, "Dr. Ahmed", "310");
        addCourse("DBS", "Database Systems", 3, "Dr. DB", "311");
        addCourse("CHEM TH", "Chemistry Theory", 2, "Dr. Chem", "312");
        addCourse("CHEM LAB", "Chemistry Lab", 1, "Dr. Chem", "Lab 5");
        addCourse("ADSS", "Advanced Software Systems", 3, "Dr. Soft", "313");
        // Add any other required courses here
    }

    private void addCourse(String code, String name, int credits, String teacher, String room) {
        Map<String, Object> course = new HashMap<>();
        course.put("name", name);
        course.put("credits", credits);
        course.put("teacher", teacher);
        course.put("room", room);
        courses.put(code, course);
    }

    public Map<String, Object> getCourseDetails(String courseCode) {
        return courses.get(courseCode);
    }

    public boolean isValidCourse(String courseCode) {
        return courses.containsKey(courseCode);
    }

    public List<Map<String, Object>> getAllCourses() {
        List<Map<String, Object>> courseList = new ArrayList<>();
        for (Map.Entry<String, Map<String, Object>> entry : courses.entrySet()) {
            Map<String, Object> course = new HashMap<>(entry.getValue());
            course.put("code", entry.getKey());
            courseList.add(course);
        }
        return courseList;
    }
} 