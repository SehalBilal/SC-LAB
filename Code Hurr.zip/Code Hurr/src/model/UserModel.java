package model;

import java.util.*;

public class UserModel {
    private String name;
    private String regNo;
    private String program;
    private String semester;
    private List<String[]> registeredCourses;
    private Map<String, Set<String>> registeredCoursesMap;
    private Map<String, String> userCredentials;

    public UserModel() {
        this.name = "Muhammad ALI";
        this.regNo = "04072313001";
        this.program = "BS in Computer Science";
        this.semester = "Spring 2023";
        this.registeredCourses = new ArrayList<>();
        registeredCoursesMap = new HashMap<>();
        userCredentials = new HashMap<>();
        initializeSampleData();
    }

    private void initializeSampleData() {
        // Add real student
        userCredentials.put("04072313001", "001");
        registeredCoursesMap.put("04072313001", new HashSet<>());
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getRegNo() { return regNo; }
    public void setRegNo(String regNo) { this.regNo = regNo; }
    
    public String getProgram() { return program; }
    public void setProgram(String program) { this.program = program; }
    
    public String getSemester() { return semester; }
    public void setSemester(String semester) { this.semester = semester; }
    
    public List<String[]> getRegisteredCourses() { return registeredCourses; }
    
    public void addCourse(String[] course) {
        registeredCourses.add(course);
    }

    public void clearCourses() {
        registeredCourses.clear();
    }

    public boolean authenticateUser(String username, String password) {
        // Username must be all digits
        if (!username.matches("\\d+")) return false;
        String storedPassword = userCredentials.get(username);
        return storedPassword != null && storedPassword.equals(password);
    }

    public boolean registerCourse(String username, String courseCode) {
        if (!registeredCoursesMap.containsKey(username)) {
            registeredCoursesMap.put(username, new HashSet<>());
        }
        return registeredCoursesMap.get(username).add(courseCode);
    }

    public Set<String> getRegisteredCourses(String username) {
        return registeredCoursesMap.getOrDefault(username, new HashSet<>());
    }

    public void clearRegisteredCourses(String username) {
        registeredCoursesMap.put(username, new HashSet<>());
    }

    // Pre-req check for course registration
    public boolean canRegisterCourse(String username, String courseCode, model.AcademicModel academicModel) {
        return academicModel.isPreReqPassed(username, courseCode);
    }

    // Add a registered course (all details)
    public void addRegisteredCourse(String username, String[] courseDetails) {
        if (!registeredCoursesMap.containsKey(username)) {
            registeredCoursesMap.put(username, new HashSet<>());
        }
        registeredCourses.add(courseDetails);
        registeredCoursesMap.get(username).add(courseDetails[0]); // code
    }

    // Get all registered courses (with details)
    public List<String[]> getRegisteredCoursesDetails() {
        return registeredCourses;
    }
} 