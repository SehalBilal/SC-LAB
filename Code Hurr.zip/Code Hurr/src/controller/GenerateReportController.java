package controller;

import view.GenerateReportView;

public class GenerateReportController {
    private GenerateReportView view;
    private CourseCoordinatorDashboardController parentController;

    public GenerateReportController(CourseCoordinatorDashboardController parentController) {
        this.parentController = parentController;
        this.view = new GenerateReportView(this);
    }

    public void showView() {
        view.setVisible(true);
    }

    public void backToDashboard() {
        parentController.showView();
    }
} 