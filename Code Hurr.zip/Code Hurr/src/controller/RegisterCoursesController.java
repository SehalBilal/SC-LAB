package controller;

import view.RegisterCoursesView;
import model.UserModel;
import model.CourseModel;
import model.AcademicModel;
import javax.swing.JOptionPane;

public class RegisterCoursesController {
    private RegisterCoursesView view;
    private UserModel userModel;
    private CourseModel courseModel;
    private AcademicModel academicModel;
    private String username;

    public RegisterCoursesController(String username, UserModel userModel, CourseModel courseModel, AcademicModel academicModel) {
        this.username = username;
        this.userModel = userModel;
        this.courseModel = courseModel;
        this.academicModel = academicModel;
        this.view = new RegisterCoursesView(this, courseModel, userModel, username);
    }

    public void showView() {
        view.setVisible(true);
    }

    public boolean registerCourse(String courseCode) {
        // First check if course is available for registration
        if (!academicModel.isCourseAvailableForRegistration(courseCode)) {
            JOptionPane.showMessageDialog(view, "This course is not available for registration in the current semester.");
            return false;
        }
        
        // Then check if pre-requisites are passed
        if (!academicModel.isPreReqPassed(username, courseCode)) {
            JOptionPane.showMessageDialog(view, "Cannot register course. Either pre-requisite not passed or course already completed.");
            return false;
        }
        
        if (userModel.registerCourse(username, courseCode)) {
            return true;
        } else {
            JOptionPane.showMessageDialog(view, "Failed to register course. Please try again.");
            return false;
        }
    }

    public void navigateTo(int idx) {
        view.dispose();
        new DashboardController(username, userModel, courseModel, academicModel).navigateTo(idx);
    }
} 